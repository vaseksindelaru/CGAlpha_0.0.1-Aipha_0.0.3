# oracle_backlog_v7.md
## cgAlpha_0.0.1 — Backlog Oracle v7 (post sesión de reconstrucción v6)

```
╔══════════════════════════════════════════════════════════════════════╗
║  GENERADO POR    : Lila — sesión de reconstrucción Oracle v6        ║
║  FECHA           : [FECHA DE LA SESIÓN]                             ║
║  MODELO USADO    : [Opus 4.8 / modelo disponible en esa fecha]      ║
║  ORACLE v6 OOS   : [COMPLETAR — resultado del primer A/B post-v6]   ║
║  PROPÓSITO       : Mejoras identificadas pero fuera del scope v6    ║
╚══════════════════════════════════════════════════════════════════════╝
```

> Instrucciones para Lila durante la sesión:
> Cada mejora que identifiques pero no puedas implementar en esta sesión
> va aquí. Clasifica cada una como Cat.1/2/3. Documenta el prerequisito
> que debe cumplirse antes de ejecutarla. Respeta el orden topológico:
> si B depende de A, A va primero en la lista.

---

## Criterio de inclusión en este backlog

Una mejora va aquí si:
- Requiere modificar un módulo protegido (§4 del brief)
- Requiere dataset de ≥N muestras que aún no existe
- Requiere que Oracle v6 esté estable en producción primero
- Su complejidad excede el scope de una sesión de reconstrucción

---

## Cat.1 — Automáticas (sin aprobación humana)

Cambios paramétricos simples. CodeCraftSage los aplica solo
cuando el canal detecta que el prerequisito se cumple.

---

### V7-C1-001 — [TÍTULO]

```json
{
  "id": "V7-C1-001",
  "categoria": 1,
  "titulo": "[Descripción en una línea]",
  "archivo": "[ruta exacta]",
  "atributo": "[nombre del parámetro o método]",
  "cambio": {
    "actual": "[valor o comportamiento actual]",
    "propuesto": "[valor o comportamiento propuesto]",
    "razon": "[por qué este cambio mejora el Oracle]"
  },
  "prerequisito": "[qué debe ocurrir primero]",
  "evidencia_requerida": "[qué dato OOS confirmaría que el cambio es correcto]",
  "riesgo": "bajo",
  "estimacion_impacto_oos": "[+X% o descripción cualitativa]"
}
```

---

### V7-C1-002 — Migrar sklearn si hay upgrade disponible

```json
{
  "id": "V7-C1-002",
  "categoria": 1,
  "titulo": "Verificar FrozenEstimator en sklearn ≥ 1.8 cuando el entorno actualice",
  "archivo": "cgalpha_v3/lila/llm/oracle_v6.py",
  "atributo": "CalibratedClassifierCV",
  "cambio": {
    "actual": "wrapper condicional FrozenEstimator (para compatibilidad sklearn 1.6/1.7/1.8)",
    "propuesto": "FrozenEstimator directo sin wrapper cuando sklearn ≥ 1.8 detectado",
    "razon": "Eliminar código de compatibilidad una vez que sklearn 1.8 sea el estándar"
  },
  "prerequisito": "sklearn >= 1.8 instalado en el entorno de producción",
  "evidencia_requerida": "pip show scikit-learn muestra versión ≥ 1.8",
  "riesgo": "bajo",
  "estimacion_impacto_oos": "ninguno — cambio cosmético"
}
```

---

## Cat.2 — Semi-automáticas (requieren aprobación humana)

Cambios que afectan la arquitectura o la calidad del dataset.
El Orchestrator los encola. El operador aprueba vía GUI.

---

### V7-C2-001 — [TÍTULO]

```json
{
  "id": "V7-C2-001",
  "categoria": 2,
  "titulo": "[Descripción]",
  "componentes_afectados": ["[archivo1]", "[archivo2]"],
  "cambio": {
    "descripcion": "[qué cambia y cómo]",
    "impacto_dataset": "[modifica el schema? añade campos? requiere re-cosecha?]",
    "impacto_modelo": "[requiere re-entrenar? cambia las features?]"
  },
  "prerequisito": "[condición que debe cumplirse primero]",
  "dependencias": ["[ID de otra mejora que debe ir antes]"],
  "criterio_exito": "[cómo saber que el cambio funcionó — métrica OOS]",
  "riesgo": "medio",
  "estimacion_esfuerzo": "[horas de implementación estimadas]"
}
```

---

### V7-C2-002 — Benchmark RF vs XGBoost cuando dataset ≥ 500 samples

```json
{
  "id": "V7-C2-002",
  "categoria": 2,
  "titulo": "Benchmark RandomForest vs XGBoost/LightGBM con dataset completo",
  "componentes_afectados": ["cgalpha_v3/scripts/train_oracle_ab.py"],
  "cambio": {
    "descripcion": "Añadir XGBoost y LightGBM como modelos challenger en el A/B runner. Comparar Brier Score y OOS accuracy en walk-forward.",
    "impacto_dataset": "ninguno — usa el dataset existente",
    "impacto_modelo": "potencial mejora del Brier Score si GBM captura mejor las interacciones no lineales"
  },
  "prerequisito": "dataset FULL ≥ 500 samples entrenables (actualmente ~35, necesita ~9 meses de cosecha)",
  "dependencias": [],
  "criterio_exito": "GBM Brier Score < RF Brier Score en walk-forward con ≥3 ventanas",
  "riesgo": "bajo",
  "estimacion_esfuerzo": "3 horas"
}
```

---

### V7-C2-003 — DuplicateWatchdog integrado al Orchestrator

```json
{
  "id": "V7-C2-003",
  "categoria": 2,
  "titulo": "Integrar DuplicateWatchdog al canal de evolución como proceso Cat.2 automático",
  "componentes_afectados": [
    "cgalpha_v3/gui/server.py",
    "cgalpha_v3/lila/evolution_orchestrator.py"
  ],
  "cambio": {
    "descripcion": "El DuplicateWatchdog ya existe como módulo standalone. Conectarlo al startup de server.py y hacer que sus anomalías generen propuestas Cat.2 automáticas al Orchestrator.",
    "impacto_dataset": "ninguno — solo monitoreo",
    "impacto_modelo": "indirecto — mantiene el dataset limpio para futuros re-entrenamientos"
  },
  "prerequisito": "oracle_v6.py estable en producción (≥2 semanas sin regresiones)",
  "dependencias": [],
  "criterio_exito": "watchdog_anomalies.jsonl vacío durante 30 días consecutivos",
  "riesgo": "bajo",
  "estimacion_esfuerzo": "2 horas"
}
```

---

### V7-C2-004 — Walk-forward con datos de mercado reales (no sintéticos)

```json
{
  "id": "V7-C2-004",
  "categoria": 2,
  "titulo": "Validación walk-forward sobre dataset 100% FULL L2 (sin samples legacy/synth)",
  "componentes_afectados": ["cgalpha_v3/scripts/train_oracle_ab.py"],
  "cambio": {
    "descripcion": "Cuando Set A tenga ≥200 samples FULL, ejecutar un A/B especial que compara Set B legacy+L2 vs Set A puro L2 usando walk-forward de 3 ventanas temporales. Esta comparación decide si los datos sintéticos del bridge pueden retirarse.",
    "impacto_dataset": "ninguno — read-only",
    "impacto_modelo": "posible sustitución del champion Set B por Set A si métricas mejoran"
  },
  "prerequisito": "Set A tiene ≥200 samples FULL entrenables con distribución horaria equilibrada",
  "dependencias": ["V7-C2-002"],
  "criterio_exito": "Set A puro L2 supera a Set B legacy+L2 en Brier Score con OOS ≥30 muestras",
  "riesgo": "medio — si Set A no mejora, los datos sintéticos deben mantenerse indefinidamente",
  "estimacion_esfuerzo": "4 horas + tiempo de cosecha de datos"
}
```

---

## Cat.3 — Supervisadas (sesión humana obligatoria)

Cambios arquitectónicos que tocan módulos protegidos o que
implican decisiones que el humano debe aprobar explícitamente.

---

### V7-C3-001 — [TÍTULO]

```json
{
  "id": "V7-C3-001",
  "categoria": 3,
  "titulo": "[Descripción]",
  "modulos_protegidos_afectados": ["[lista de módulos del §4 que requieren modificación]"],
  "justificacion_cat3": "[por qué esto requiere sesión humana y no puede ser Cat.2]",
  "cambio": {
    "descripcion": "[qué cambia]",
    "impacto_arquitectonico": "[qué decisiones de diseño invalida o extiende]"
  },
  "prerequisito": "[condición bloqueante]",
  "dependencias": ["[IDs que deben completarse primero]"],
  "criterio_exito": "[cómo verificar que el cambio fue correcto]",
  "riesgo": "alto",
  "estimacion_esfuerzo": "[días de trabajo]",
  "reflexion_critica_requerida": "[sección del Prompt Fundacional que toca]"
}
```

---

### V7-C3-002 — Alpha Lab: chat con Lila en la GUI

```json
{
  "id": "V7-C3-002",
  "categoria": 3,
  "titulo": "Implementar pestaña Alpha Lab en la GUI — chat con Lila + historial + selector de modelo",
  "modulos_protegidos_afectados": ["cgalpha_v3/gui/server.py", "cgalpha_v3/gui/static/index.html"],
  "justificacion_cat3": "Modifica server.py (módulo protegido) y añade una interfaz de interacción directa con el LLM desde la GUI — decisión arquitectónica que requiere aprobación humana explícita sobre qué capacidades tiene Lila en ese entorno.",
  "cambio": {
    "descripcion": "Nueva pestaña en la Control Room: /api/alpha-lab/chat endpoint, historial persistente en memoria nivel 2, selector de modelo (Opus/Sonnet/local), visor de diffs de código propuestos.",
    "impacto_arquitectonico": "Primera interfaz de interacción conversacional directa. Define el contrato entre el operador y Lila fuera de las propuestas formales Cat.1/2/3."
  },
  "prerequisito": "oracle_v6 estable ≥4 semanas. DuplicateWatchdog integrado (V7-C2-003).",
  "dependencias": ["V7-C2-003"],
  "criterio_exito": "El operador puede preguntar sobre el estado del Oracle y recibir una respuesta que referencia datos reales del proyecto sin salir de la GUI.",
  "riesgo": "medio — no toca el canal de evolución, solo añade UI",
  "estimacion_esfuerzo": "2-3 días",
  "reflexion_critica_requerida": "§2.7 del Prompt Fundacional — Learning GUI dividido en /learning/operator y /learning/lila"
}
```

---

### V7-C3-003 — Reflexión crítica §6 sobre el Prompt Fundacional

```json
{
  "id": "V7-C3-003",
  "categoria": 3,
  "titulo": "Primera reflexión crítica §6: ¿el §3.6 sigue siendo correcto después de oracle_v6?",
  "modulos_protegidos_afectados": ["LILA_V4_PROMPT_FUNDACIONAL.md"],
  "justificacion_cat3": "Modifica el mantra IDENTITY. Requiere 3 ciclos OOS de validación + aprobación humana. Es el mecanismo de independencia progresiva documentado en §6.",
  "cambio": {
    "descripcion": "Revisar si el orden de ejecución de bugs en §3.6 (BUG-4→BUG-2→BUG-6→BUG-1→BUG-5→BUG-3→BUG-8) sigue siendo el correcto con oracle_v6 en producción. oracle_v6 resuelve varios de estos estructuralmente — el orden puede simplificarse.",
    "impacto_arquitectonico": "Actualización del mantra IDENTITY — el cambio más controlado del sistema"
  },
  "prerequisito": "oracle_v6 con ≥3 ciclos OOS reales. Métricas consistentes (CV std < 0.05). Validación walk-forward completada.",
  "dependencias": ["V7-C2-004"],
  "criterio_exito": "El mantra actualizado es más preciso y menos redundante sin comprometer ningún invariante de seguridad.",
  "riesgo": "bajo — es una actualización de documentación, no de código",
  "estimacion_esfuerzo": "1 sesión de 2 horas",
  "reflexion_critica_requerida": "§6.3 — ciclo de vida de una reflexión crítica"
}
```

---

## Orden topológico de ejecución recomendado

```
INMEDIATO (paralelo a cosecha):
  V7-C1-001 → cualquier Cat.1 identificado durante la sesión
  V7-C1-002 → cuando sklearn se actualice

CORTO PLAZO (después de oracle_v6 estable ≥2 semanas):
  V7-C2-003 → DuplicateWatchdog integrado al canal

MEDIO PLAZO (cuando Set A tenga ≥200 samples FULL):
  V7-C2-002 → Benchmark RF vs XGBoost
  V7-C2-004 → Walk-forward puro L2

LARGO PLAZO (después de V7-C2-004 completado):
  V7-C3-002 → Alpha Lab GUI
  V7-C3-003 → Reflexión crítica §6

NUNCA ANTES DE oracle_v6 estable:
  V7-C3-001 → [cualquier cambio arquitectónico mayor identificado]
```

---

## Métricas para decidir cuándo ejecutar la próxima sesión de reconstrucción (Oracle v7)

```
Trigger: 2 de estos 3 criterios cumplidos simultáneamente:

□ OOS accuracy de Set A (puro L2) ≥ 0.80 en walk-forward
□ Dataset FULL tiene ≥ 500 samples con distribución horaria equilibrada
□ Al menos 2 mejoras Cat.2 del backlog v7 están en producción y estables

Prohibición: No ejecutar sesión v7 si oracle_v6 lleva < 8 semanas en producción.
```

---

*Generado por Lila durante la sesión de reconstrucción del Oracle v6.*
*[FECHA DE LA SESIÓN]*
*Próxima revisión: cuando trigger de sesión v7 se cumpla.*
