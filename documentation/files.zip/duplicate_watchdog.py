"""
cgalpha_v3/lila/duplicate_watchdog.py
──────────────────────────────────────
Monitor periódico que detecta clones en training_dataset_v2.jsonl
y los reporta al Orchestrator como propuesta Cat.2.

Motivación:
  B-008 Cross-Polarity Clones demostró que la deduplicación en el
  punto de captura puede fallar de formas no anticipadas. Este watchdog
  actúa como red de seguridad reactiva: si algún clon llega al dataset,
  lo detecta en ≤30 minutos y propone la purga.

Uso directo:
  python3 cgalpha_v3/lila/duplicate_watchdog.py
  python3 cgalpha_v3/lila/duplicate_watchdog.py --once
  python3 cgalpha_v3/lila/duplicate_watchdog.py --interval 1800

Integración con Orchestrator (desde server.py):
  watchdog = DuplicateWatchdog(dataset_path, orchestrator)
  watchdog.start()   # arranca thread en background
  watchdog.stop()    # para limpiamente
"""

from __future__ import annotations

import json
import logging
import threading
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger("duplicate_watchdog")


# ─────────────────────────────────────────────────────────────────────────────
# CONFIGURACIÓN
# ─────────────────────────────────────────────────────────────────────────────

DEFAULT_DATASET_PATH = Path(
    "aipha_memory/operational/training_dataset_v2.jsonl"
)
DEFAULT_INTERVAL_SECONDS = 1800  # 30 minutos
WATCHDOG_LOG_PATH = Path(
    "aipha_memory/operational/watchdog_anomalies.jsonl"
)


# ─────────────────────────────────────────────────────────────────────────────
# TIPOS
# ─────────────────────────────────────────────────────────────────────────────

class CloneGroup:
    """Un grupo de muestras que comparten el mismo fingerprint físico."""

    def __init__(self, fingerprint: str):
        self.fingerprint = fingerprint
        self.sample_ids:   list[str] = []
        self.directions:   list[str] = []
        self.outcomes:     list[str] = []
        self.timestamps:   list[str] = []
        self.is_cross_polarity: bool = False

    def add(self, sample_id: str, direction: str,
            outcome: str, capture_ts: str) -> None:
        self.sample_ids.append(sample_id)
        self.directions.append(direction)
        self.outcomes.append(outcome)
        self.timestamps.append(capture_ts)
        # Cross-polarity: mismo fingerprint pero zonas de distinta dirección
        if len(set(self.directions)) > 1:
            self.is_cross_polarity = True

    @property
    def count(self) -> int:
        return len(self.sample_ids)

    def to_dict(self) -> dict:
        return {
            "fingerprint":       self.fingerprint,
            "clone_count":       self.count,
            "is_cross_polarity": self.is_cross_polarity,
            "sample_ids":        self.sample_ids,
            "directions":        self.directions,
            "outcomes":          self.outcomes,
            "timestamps":        self.timestamps,
        }


# ─────────────────────────────────────────────────────────────────────────────
# CLASE PRINCIPAL
# ─────────────────────────────────────────────────────────────────────────────

class DuplicateWatchdog:
    """
    Escanea training_dataset_v2.jsonl buscando muestras duplicadas.
    Cuando encuentra clones, genera un reporte y opcionalmente lo
    envía al Orchestrator como propuesta Cat.2.

    El fingerprint que usa es el correcto post-B-008:
      f"{capture_ts_unix_ms}_{retest_price}"
    (sin zone_direction — ver Codex D-004)
    """

    def __init__(
        self,
        dataset_path: Path = DEFAULT_DATASET_PATH,
        orchestrator=None,          # EvolutionOrchestratorV4 | None
        interval_seconds: int = DEFAULT_INTERVAL_SECONDS,
    ):
        self.dataset_path    = Path(dataset_path)
        self.orchestrator    = orchestrator
        self.interval        = interval_seconds
        self._thread: Optional[threading.Thread] = None
        self._stop_event     = threading.Event()
        self._last_scan_ts:  Optional[float] = None
        self._last_anomalies: list[CloneGroup] = []

    # ─────────────────────────────────────────────────────────────────────

    def scan(self) -> list[CloneGroup]:
        """
        Escanea el dataset y retorna los grupos de clones encontrados.
        Puede llamarse directamente para un escaneo puntual.
        """
        if not self.dataset_path.exists():
            logger.warning(f"Dataset no encontrado: {self.dataset_path}")
            return []

        groups: dict[str, CloneGroup] = defaultdict(lambda: None)
        line_errors = 0

        with open(self.dataset_path, "r", encoding="utf-8") as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    sample = json.loads(line)
                    fingerprint = self._compute_fingerprint(sample)
                    if fingerprint is None:
                        continue

                    if groups[fingerprint] is None:
                        groups[fingerprint] = CloneGroup(fingerprint)

                    groups[fingerprint].add(
                        sample_id  = self._get_sample_id(sample),
                        direction  = self._get_direction(sample),
                        outcome    = self._get_outcome(sample),
                        capture_ts = self._get_capture_ts(sample),
                    )

                except (json.JSONDecodeError, KeyError) as e:
                    line_errors += 1
                    logger.warning(
                        f"Línea {line_num} malformada en {self.dataset_path}: {e}"
                    )

        # Solo retornar grupos con más de una muestra
        clones = [g for g in groups.values() if g is not None and g.count > 1]

        self._last_scan_ts   = time.time()
        self._last_anomalies = clones

        if line_errors:
            logger.warning(f"Watchdog: {line_errors} líneas malformadas omitidas")

        return clones

    def report(self, clones: list[CloneGroup]) -> dict:
        """
        Genera un reporte estructurado de los clones encontrados.
        """
        cross_polarity = [c for c in clones if c.is_cross_polarity]
        same_direction = [c for c in clones if not c.is_cross_polarity]

        report = {
            "scan_ts":           datetime.now(timezone.utc).isoformat(),
            "dataset_path":      str(self.dataset_path),
            "total_clone_groups": len(clones),
            "cross_polarity_groups": len(cross_polarity),
            "same_direction_groups": len(same_direction),
            "total_contaminated_samples": sum(c.count for c in clones),
            "samples_to_purge":  sum(c.count - 1 for c in clones),
            "clone_groups":      [c.to_dict() for c in clones],
        }

        if clones:
            logger.warning(
                f"⚠️  Watchdog detectó {len(clones)} grupos de clones "
                f"({len(cross_polarity)} cross-polarity, "
                f"{len(same_direction)} same-direction). "
                f"Muestras a purgar: {report['samples_to_purge']}"
            )
        else:
            logger.info("✓ Watchdog: dataset limpio — sin duplicados detectados")

        return report

    def persist_anomaly(self, report: dict) -> None:
        """Guarda el reporte en el log de anomalías."""
        if not report["total_clone_groups"]:
            return
        WATCHDOG_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(WATCHDOG_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(report, ensure_ascii=False) + "\n")

    def propose_purge(self, report: dict) -> Optional[str]:
        """
        Envía una propuesta Cat.2 al Orchestrator para purgar los clones.
        Retorna el proposal_id o None si no hay Orchestrator disponible.
        """
        if not self.orchestrator:
            logger.info(
                "Watchdog: no hay Orchestrator disponible. "
                "Ejecutar clean_dataset_duplicates.py manualmente."
            )
            return None

        if not report["total_clone_groups"]:
            return None

        try:
            from cgalpha_v3.lila.llm.proposer import TechnicalSpec
            spec = TechnicalSpec(
                change_type     = "bugfix",
                target_file     = str(self.dataset_path),
                target_attribute= "clone_contamination",
                old_value       = float(report["total_contaminated_samples"]),
                new_value       = float(report["total_contaminated_samples"]
                                        - report["samples_to_purge"]),
                reason          = (
                    f"DuplicateWatchdog detectó {report['total_clone_groups']} "
                    f"grupos de clones ({report['cross_polarity_groups']} "
                    f"cross-polarity). Purgar {report['samples_to_purge']} "
                    f"muestras duplicadas. Ver watchdog_anomalies.jsonl."
                ),
                causal_score_est= 0.95,
                confidence      = 0.98,
            )
            result = self.orchestrator.process_proposal(spec)
            logger.info(
                f"Watchdog: propuesta de purga enviada → {result.proposal_id}"
            )
            return result.proposal_id

        except Exception as e:
            logger.error(f"Watchdog: error al proponer purga: {e}")
            return None

    # ─────────────────────────────────────────────────────────────────────
    # LOOP EN BACKGROUND
    # ─────────────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Arranca el watchdog en un thread de background."""
        if self._thread and self._thread.is_alive():
            logger.warning("Watchdog ya está en ejecución")
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop,
            name="DuplicateWatchdog",
            daemon=True,
        )
        self._thread.start()
        logger.info(
            f"✓ DuplicateWatchdog iniciado (intervalo: {self.interval}s)"
        )

    def stop(self) -> None:
        """Para el watchdog limpiamente."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("DuplicateWatchdog detenido")

    def _loop(self) -> None:
        """Loop principal del thread de background."""
        while not self._stop_event.is_set():
            try:
                clones = self.scan()
                report = self.report(clones)
                if clones:
                    self.persist_anomaly(report)
                    self.propose_purge(report)
            except Exception as e:
                logger.error(f"Watchdog error en ciclo: {e}")
            self._stop_event.wait(timeout=self.interval)

    # ─────────────────────────────────────────────────────────────────────
    # FINGERPRINT — post B-008 (sin zone_direction)
    # ─────────────────────────────────────────────────────────────────────

    def _compute_fingerprint(self, sample: dict) -> Optional[str]:
        """
        Fingerprint correcto post B-008 v2 (Codex D-004):
          f"{capture_ts_unix_ms}_{retest_price}"
        Sin zone_direction — esa es la causa raíz de los Cross-Polarity Clones.
        """
        try:
            meta    = sample.get("_meta", {})
            l2      = sample.get("l2_snapshot_at_touch", {})
            zone    = sample.get("zone_geometry", {})

            ts    = meta.get("capture_ts_unix_ms")
            price = l2.get("retest_price") or zone.get("zone_top")

            if ts is None or price is None:
                return None

            return f"{int(ts)}_{float(price):.2f}"

        except (TypeError, ValueError):
            return None

    def _get_sample_id(self, sample: dict) -> str:
        return sample.get("_meta", {}).get("sample_id", "unknown")

    def _get_direction(self, sample: dict) -> str:
        return sample.get("zone_geometry", {}).get("direction", "unknown")

    def _get_outcome(self, sample: dict) -> str:
        outcome = sample.get("outcome")
        if isinstance(outcome, dict):
            return outcome.get("label", "pending")
        return str(outcome) if outcome else "pending"

    def _get_capture_ts(self, sample: dict) -> str:
        return sample.get("_meta", {}).get("capture_ts_utc", "unknown")

    # ─────────────────────────────────────────────────────────────────────
    # ESTADO PARA GUI
    # ─────────────────────────────────────────────────────────────────────

    def get_status(self) -> dict:
        """Estado del watchdog para el endpoint /api/alpha-lab/watchdog."""
        return {
            "running":         self._thread is not None and self._thread.is_alive(),
            "interval_seconds": self.interval,
            "last_scan_ts":    self._last_scan_ts,
            "last_scan_ago_s": (time.time() - self._last_scan_ts)
                               if self._last_scan_ts else None,
            "last_anomalies":  len(self._last_anomalies),
            "dataset_path":    str(self.dataset_path),
            "dataset_exists":  self.dataset_path.exists(),
        }


# ─────────────────────────────────────────────────────────────────────────────
# EJECUCIÓN DIRECTA
# ─────────────────────────────────────────────────────────────────────────────

def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="DuplicateWatchdog — monitor de clones en el dataset"
    )
    parser.add_argument(
        "--once", action="store_true",
        help="Ejecutar un solo escaneo y salir"
    )
    parser.add_argument(
        "--interval", type=int, default=DEFAULT_INTERVAL_SECONDS,
        help=f"Intervalo en segundos entre escaneos (default: {DEFAULT_INTERVAL_SECONDS})"
    )
    parser.add_argument(
        "--dataset", type=str, default=str(DEFAULT_DATASET_PATH),
        help="Ruta al dataset JSONL"
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s — %(message)s",
    )

    watchdog = DuplicateWatchdog(
        dataset_path     = Path(args.dataset),
        orchestrator     = None,
        interval_seconds = args.interval,
    )

    if args.once:
        print(f"\nEscaneando {args.dataset}...")
        clones = watchdog.scan()
        report = watchdog.report(clones)

        print(f"\n{'='*50}")
        print(f"RESULTADO DEL ESCANEO")
        print(f"{'='*50}")
        print(f"Grupos de clones:     {report['total_clone_groups']}")
        print(f"Cross-polarity:       {report['cross_polarity_groups']}")
        print(f"Muestras afectadas:   {report['total_contaminated_samples']}")
        print(f"A purgar:             {report['samples_to_purge']}")

        if clones:
            print(f"\nDETALLE:")
            for g in clones:
                print(f"  Fingerprint: {g.fingerprint}")
                print(f"  IDs:         {g.sample_ids}")
                print(f"  Direcciones: {g.directions}")
                print(f"  Outcomes:    {g.outcomes}")
                print(f"  Cross-pol:   {g.is_cross_polarity}")
                print()
            watchdog.persist_anomaly(report)
            print(f"Anomalía guardada en {WATCHDOG_LOG_PATH}")
        else:
            print("\n✓ Dataset limpio — sin duplicados")
    else:
        print(f"Iniciando watchdog (intervalo: {args.interval}s)...")
        print("Ctrl+C para detener")
        watchdog.start()
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            watchdog.stop()
            print("\nWatchdog detenido")


if __name__ == "__main__":
    main()
