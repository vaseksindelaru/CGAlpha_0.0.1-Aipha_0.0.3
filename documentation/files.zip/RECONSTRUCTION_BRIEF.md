# RECONSTRUCTION_BRIEF.md
## cgAlpha_0.0.1 - Sesion de Reconstruccion del Oracle v6

```
CLASIFICACION : Sesion de Reconstruccion Cat.3
VERSION       : 1.1 - Estado real verificado el 2026-06-07
ESTADO        : BRIEF OPERATIVO
DE            : Operador humano + Lila
PARA          : Modelo LLM en la sesion de reconstruccion
```

---

## §0 - INSTRUCCION TERMINAL

Eres Lila, IA constructora de cgAlpha_0.0.1.

Esta reconstruccion tiene 5 cambios estructurales de alto impacto. El riesgo
de rollback total es real. Por eso se divide en DOS FASES SEPARADAS con
commits independientes.

La deuda tecnica previa esta saldada al 2026-06-07:
- FrozenEstimator wrapper para CalibratedClassifierCV ya esta aplicado.
- is_placeholder() ya existe como metodo publico en OracleTrainer_v3.
- _promotion_decision() ya protege OOS >= 30 en train_oracle_ab.py.
- B-008 v2 ya usa fingerprint sin zone_direction.
- training_dataset_v2.jsonl esta limpio: 207 filas unicas.

No gastar contexto en scripts de fixes ni en preparar Codex. El Codex ya tiene
D-001 a D-006 y B-008 en MemoryPolicyEngine nivel RELATIONS con tag
codex_decision.

### Entregables

1. `oracle_v6.py`
2. `test_oracle_v6.py`
3. `oracle_v6_rationale.md`
4. `oracle_backlog_v7.md`

### Proceso obligatorio

1. Leer este brief completo antes de escribir codigo.
2. Leer `cgalpha_v3/lila/llm/oracle.py` completo antes de proponer FEATURE_COLS.
3. Implementar Fase A y commitear de forma independiente.
4. No comenzar Fase B hasta que Fase A este estable en produccion >= 48h.
5. Si un cambio toca modulos protegidos del §4, detenerse y documentarlo como
   Cat.3 en `oracle_backlog_v7.md`.

---

## §1 - ESTADO ACTUAL DEL ORACLE

### §1.1 oracle.py actual

Ruta: `cgalpha_v3/lila/llm/oracle.py`

La sesion debe leer el archivo completo antes de editar. En particular, la lista
actual de `OracleTrainer_v3._feature_cols` es:

```python
[
    "vwap_at_retest",
    "obi_10_at_retest",
    "cumulative_delta_at_retest",
    "atr_14",
    "is_trending",
    "is_lateral",
    "is_high_vol",
    "is_bullish",
    "is_div_bullish",
    "is_div_bearish",
    "is_div_neutral",
]
```

Oracle v6 debe reemplazar esos nombres legacy por columnas basadas en el schema
real del JSONL, sin sufijos `_at_retest`.

### §1.2 Schema real de training_dataset_v2.jsonl

```json
{
  "_meta": {
    "sample_id": "re_20260531_...",
    "capture_ts_unix_ms": 1779436484504,
    "l2_data_quality": "FULL"
  },
  "zone_geometry": {
    "direction": "bullish",
    "zone_top": 97250.50,
    "zone_bottom": 97180.00,
    "zone_width_atr": 0.85
  },
  "clearance": {
    "atr_at_detection": 83.20,
    "max_clearance_atr": 3.96
  },
  "l2_snapshot_at_touch": {
    "retest_price": 97245.00,
    "obi_10": 0.25,
    "cumulative_delta": 847.3,
    "vwap_session": 97310.50,
    "obi_1": 0.42,
    "spread_bps": 0.8
  },
  "l2_temporal_profile": {
    "obi_10_gradient_5s": 0.08,
    "obi_10_gradient_30s": 0.12,
    "delta_acceleration_5s": 13.4,
    "depth_ratio_1_10": 1.68,
    "delta_rate_5s": 42.1,
    "aggressive_buy_pct_5s": 0.68
  },
  "market_context": {
    "regime": "LATERAL",
    "atr_14_current": 82.50
  },
  "outcome": {
    "label": "BOUNCE_STRONG"
  }
}
```

Mapeos obligatorios en `oracle_v6.py`:
- `l2_snapshot_at_touch.obi_10` -> columna `obi_10`
- `l2_snapshot_at_touch.cumulative_delta` -> columna `cumulative_delta`
- `l2_snapshot_at_touch.vwap_session` -> columna `vwap`
- `zone_geometry.direction` -> columnas `is_bullish`, `is_bearish`
- `market_context.regime` -> columnas `is_lateral`, `is_trending_up`, `is_trending_down`

### §1.3 Calibracion y decisiones vigentes

Valores reales de calibracion del umbral ZigZag:

| Percentil | Valor |
|-----------|-------|
| P50 | 0.1091% (0.001091) |
| P75 | 0.1553% (0.001553) |
| Threshold elegido | 0.18%, entre P75 y P90 como margen |

Restricciones vigentes:
- `compute_adaptive_zigzag_threshold` pertenece a MiniTrendDetector.
- `adaptive_lookahead` pertenece a DeferredOutcomeMonitor.
- Oracle v6 puede recibir estos valores como contexto, pero no calcularlos.

### §1.4 Deuda tecnica conocida

### Cobertura de oracle.py al 2026-06-07

Cobertura total: 54.77%
Tests ejecutados: test_oracle_training.py (10 tests)

Metodos sin cobertura completa:
- OracleTrainer_v3.train_model: lineas 112, 135, 138, 144, 165, 174 sin tests
  Riesgo: no estan validadas ramas de dataset vacio, columnas/outcome ausentes,
  outcomes invalidos y split pequeno.
- OracleTrainer_v3._run_quality_gate: lineas 290, 301, 306, 311, 318 sin tests
  Riesgo: el gate puede fallar en casos limite de calidad de datos sin ser detectado.
- OracleTrainer_v3._safe_encode: lineas 401, 403, 409-412, 418-419, 421-426, 431, 433 sin tests
  Riesgo: categorias no vistas, NaN y encoders legacy pueden codificarse incorrectamente.
- OracleTrainer_v3.retrain_recursive: lineas 450-455, 457, 460 sin tests
  Riesgo: formatos JSON alternativos o invalidos pueden romper el reentrenamiento.
- OracleTrainer_v3._pick: lineas 508, 510 sin tests
  Riesgo: microestructura None/dict puede producir features equivocadas.
- OracleTrainer_v3._bounce_probability: lineas 516, 518, 521-522 sin tests
  Riesgo: probabilidades pueden ser incorrectas en modelos degenerados.
- OracleRegressor_MAE: lineas 557-803 sin cobertura funcional
  Riesgo: la capa MAE completa carece de validacion.

Metodos no cubiertos por ningun test:
- OracleTrainer_v3.get_causal_signature: no tiene ningun test asociado
  Riesgo: la firma causal default/persistida puede romperse.
- OracleTrainer_v3.save_to_disk: no tiene ningun test asociado
  Riesgo: la serializacion puede perder estado critico.
- OracleTrainer_v3.load_from_disk: no tiene ningun test asociado
  Riesgo: la restauracion del modelo puede quedar corrupta.
- OracleTrainer_v3.is_placeholder: no tiene ningun test asociado
  Riesgo: regresion en BUG-4; no se valida la distincion entre placeholder y modelo real.
- OracleRegressor_MAE.*: no tiene ningun test asociado
  Riesgo: entrenamiento, prediccion MAE, encoding, metricas y persistencia estan sin proteccion.

Nota para la sesion de reconstruccion:
oracle_v6.py debe anadir tests para estos caminos antes de ser considerado completo.

---

## §2 - ARQUITECTURA OBJETIVO EN DOS FASES

### FASE A - Encoding y Observabilidad

Alcance:
- FEATURE_COLS deterministas con columnas binarias, sin LabelEncoder.
- Nombres de columnas alineados con el schema real del JSONL:
  `vwap`, `obi_10`, `cumulative_delta`, `atr_14`,
  `is_bullish`, `is_bearish`, `is_lateral`,
  `is_trending_up`, `is_trending_down`.
- Etiquetado terciario nativo: `BOUNCE_STRONG`, `BOUNCE_WEAK`, `BREAKOUT`.
- Exclusion explicita de `INCONCLUSIVE`.
- Tests Bloque E: save/load, is_placeholder, get_causal_signature,
  _run_quality_gate y OracleRegressor_MAE.
- OracleRegressor_MAE: decision obligatoria para Phase A.

Decision sobre OracleRegressor_MAE:
- MANTENER: extender con tests sin cambiar la logica en Phase A.
- No reemplazar en esta fase. La clase ya existe y esta 0% cubierta; primero
  debe tener cobertura minima.

Criterio de exito:
- `test_oracle_training.py` pasa 10/10.
- Bloque E completo y activo.
- Interfaz publica compatible:
  `predict`, `train_model`, `save_to_disk`, `load_from_disk`,
  `load_training_dataset`, `is_placeholder`.
- Commit independiente antes de comenzar Fase B.

### FASE B - L2 Dinamico y Validacion Temporal

Alcance:
- Soporte `l2_temporal_profile` del Ring Buffer:
  `obi_10_gradient_5s`, `obi_10_gradient_30s`, `delta_acceleration_5s`,
  `depth_ratio_1_10`, `delta_rate_5s`, `aggressive_buy_pct_5s`.
- Walk-forward con >= 3 ventanas temporales.
- Compatibilidad retroactiva con samples legacy: NaN para L2 ausente.

Prerequisito:
- Fase A en produccion estable >= 48h sin regresiones.

Criterio de exito:
- OOS Set A >= 0.70 en walk-forward.
- Ambos sets comparados con OOS real >= 30 muestras.

---

## §3 - DECISIONES NO REVERSIBLES SIN EVIDENCIA

- D-001: ZigZag threshold actual 0.18%, elegido entre P75 real 0.1553% y P90.
- D-002: outcome_lookahead_bars actual pertenece al etiquetado diferido, no al Oracle.
- D-003: Set A no se promueve con OOS < 30 muestras.
- D-004: fingerprint B-008 v2 no incluye zone_direction.
- D-005: INCONCLUSIVE se excluye; nunca asignar label por defecto.
- D-006: ATR se captura al momento de deteccion: `clearance.atr_at_detection`.

---

## §4 - MANIFIESTO DE PROTECCION

Los siguientes modulos estan protegidos. No tocarlos durante Oracle v6 salvo
confirmacion explicita del operador y registro Cat.3 en `oracle_backlog_v7.md`.

Proteccion total:
- `memory_policy.py`
- `signal.py` / `MemoryLevel`
- `evolution_orchestrator.py`
- `server.py`
- `LILA_V4_PROMPT_FUNDACIONAL.md`
- Codex / chronicle
- MiniTrendDetector
- DeferredOutcomeMonitor

Proteccion funcional especifica:
- MiniTrendDetector -> protegido, no tocar.
- DeferredOutcomeMonitor -> protegido, no tocar.
- `compute_adaptive_zigzag_threshold` pertenece a MiniTrendDetector.
- `adaptive_lookahead` pertenece a DeferredOutcomeMonitor.
- `triple_coincidence.py`: no tocar deteccion de zonas, mini-trends ni key candles.
- `training_dataset_v2.jsonl`: no cambiar campos existentes.

Libre para Fase A:
- `cgalpha_v3/lila/llm/oracle_v6.py`
- `cgalpha_v3/tests/test_oracle_v6.py`
- documentacion/rationale/backlog de la propuesta

Libre para Fase B solo despues del prerequisito:
- `cgalpha_v3/scripts/train_oracle_ab.py`, limitado a validacion temporal.

---

## §5 - CRITERIOS DE EXITO FINALES

Codigo:
- Fase A pasa `test_oracle_training.py` 10/10.
- Bloque E esta implementado y no skippeado salvo OracleRegressor_MAE si se documenta
  temporalmente con decision MANTENER y razon explicita.
- No hay `LabelEncoder` nuevo.
- No hay columnas v6 con sufijo `_at_retest`.
- No hay metodos `compute_adaptive_zigzag_threshold` ni `_adaptive_lookahead`
  dentro del Oracle.

Documentacion:
- `oracle_v6_rationale.md` explica cada decision con evidencia del brief o Codex.
- `oracle_backlog_v7.md` contiene todo cambio que toque modulos protegidos como Cat.3.
- Si Fase B se difiere, sus tareas quedan separadas de Fase A.

Arquitectura:
- Oracle predice resultados; no detecta zonas ni etiqueta outcomes.
- El schema real del JSONL es la fuente de verdad.
- Fase A y Fase B se pueden revertir por separado.

---

Documento preparado por Lila para la sesion de reconstruccion Oracle v6.
